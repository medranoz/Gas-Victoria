/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("cortes_carga");
  collection.indexes.push("CREATE INDEX idx_cortes_carga_tanque_id ON cortes_carga (tanque_id)");
  collection.indexes.push("CREATE INDEX idx_cortes_carga_drv_id ON cortes_carga (drv_id)");
  collection.indexes.push("CREATE INDEX idx_cortes_carga_estado_corte ON cortes_carga (estado_corte)");
  collection.indexes.push("CREATE INDEX idx_cortes_carga_created ON cortes_carga (created)");
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("cortes_carga");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_cortes_carga_tanque_id"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_cortes_carga_drv_id"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_cortes_carga_estado_corte"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_cortes_carga_created"));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})