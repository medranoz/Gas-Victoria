/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("modulos_config");

  const record0 = new Record(collection);
    record0.set("nombre", "ATQs");
    record0.set("descripcion", "Gesti\u00f3n de ATQs");
    record0.set("ubicacion", "Secci\u00f3n Dashboard");
    record0.set("estado", true);
    record0.set("colecciones", ["atqs"]);
    record0.set("icono", "truck");
    record0.set("orden", 1);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("nombre", "Proveedores");
    record1.set("descripcion", "Gesti\u00f3n de proveedores");
    record1.set("ubicacion", "Secci\u00f3n Dashboard");
    record1.set("estado", true);
    record1.set("colecciones", ["proveedores"]);
    record1.set("icono", "building");
    record1.set("orden", 2);
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("nombre", "Clientes");
    record2.set("descripcion", "Gesti\u00f3n de clientes");
    record2.set("ubicacion", "Secci\u00f3n Dashboard");
    record2.set("estado", true);
    record2.set("colecciones", ["clientes"]);
    record2.set("icono", "users");
    record2.set("orden", 3);
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("nombre", "Control de Carga");
    record3.set("descripcion", "Gesti\u00f3n de carga de gas");
    record3.set("ubicacion", "Secci\u00f3n Dashboard");
    record3.set("estado", true);
    record3.set("colecciones", ["tanques_carga", "lecturas_carga", "cortes_carga"]);
    record3.set("icono", "gas-cylinder");
    record3.set("orden", 4);
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})