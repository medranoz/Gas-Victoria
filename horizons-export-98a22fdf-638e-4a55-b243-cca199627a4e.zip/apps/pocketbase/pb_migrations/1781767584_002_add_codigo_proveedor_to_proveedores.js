/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("proveedores");

  const existing = collection.fields.getByName("codigo_proveedor");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("codigo_proveedor"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "codigo_proveedor",
    required: true
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("proveedores");
    collection.fields.removeByName("codigo_proveedor");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})