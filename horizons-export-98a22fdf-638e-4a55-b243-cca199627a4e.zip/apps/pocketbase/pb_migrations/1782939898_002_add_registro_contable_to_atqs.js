/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("atqs");

  const existing = collection.fields.getByName("registro_contable");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("registro_contable"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "registro_contable",
    required: true,
    max: 50,
    pattern: "^[A-Z0-9.#\-]+$"
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("atqs");
    collection.fields.removeByName("registro_contable");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})