/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("control_recepcion");

  const existing = collection.fields.getByName("diferencia_capacidad_difcd");
  if (existing) {
    if (existing.type === "number") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("diferencia_capacidad_difcd"); // exists with wrong type, remove first
  }

  collection.fields.add(new NumberField({
    name: "diferencia_capacidad_difcd",
    required: false,
    min: 0
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("control_recepcion");
    collection.fields.removeByName("diferencia_capacidad_difcd");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})