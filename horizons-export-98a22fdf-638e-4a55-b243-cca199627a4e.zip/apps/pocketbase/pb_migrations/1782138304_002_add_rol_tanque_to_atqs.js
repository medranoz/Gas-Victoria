/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("atqs");

  const existing = collection.fields.getByName("rol_tanque");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("rol_tanque"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "rol_tanque",
    required: true,
    values: ["DE TRASPASO", "DE CONTADO"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("atqs");
    collection.fields.removeByName("rol_tanque");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})