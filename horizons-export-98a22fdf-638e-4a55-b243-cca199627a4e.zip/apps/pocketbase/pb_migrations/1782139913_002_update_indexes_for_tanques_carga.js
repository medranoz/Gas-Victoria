/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("tanques_carga");
  collection.indexes.push("CREATE UNIQUE INDEX idx_tanques_carga_numero_tanque ON tanques_carga (numero_tanque)");
  collection.indexes.push("CREATE INDEX idx_tanques_carga_drv_id ON tanques_carga (drv_id)");
  collection.indexes.push("CREATE INDEX idx_tanques_carga_estado ON tanques_carga (estado)");
  collection.indexes.push("CREATE INDEX idx_tanques_carga_origen_carga ON tanques_carga (origen_carga)");
  collection.indexes.push("CREATE INDEX idx_tanques_carga_created ON tanques_carga (created)");
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("tanques_carga");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_tanques_carga_numero_tanque"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_tanques_carga_drv_id"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_tanques_carga_estado"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_tanques_carga_origen_carga"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_tanques_carga_created"));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})