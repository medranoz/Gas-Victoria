/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("drv");
  collection.fields.removeByName("fecha_alta");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("drv");
  collection.fields.add(new DateField({
    name: "fecha_alta",
    required: true
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})