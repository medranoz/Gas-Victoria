/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("atqs");
  collection.indexes.push("CREATE UNIQUE INDEX idx_atqs_placa ON atqs (placa)");
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("atqs");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_atqs_placa"));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})