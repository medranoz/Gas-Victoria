/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("proveedores");
  collection.indexes.push("CREATE UNIQUE INDEX idx_proveedores_codigo_proveedor ON proveedores (codigo_proveedor)");
  collection.indexes.push("CREATE UNIQUE INDEX idx_proveedores_razon_social ON proveedores (razon_social)");
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("proveedores");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_proveedores_codigo_proveedor"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_proveedores_razon_social"));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})