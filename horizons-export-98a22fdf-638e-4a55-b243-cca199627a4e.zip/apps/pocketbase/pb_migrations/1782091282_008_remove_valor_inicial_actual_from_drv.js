/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("drv");
  collection.fields.removeByName("valor_inicial_actual");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("drv");
  collection.fields.add(new NumberField({
    name: "valor_inicial_actual",
    required: true,
    min: 0
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})