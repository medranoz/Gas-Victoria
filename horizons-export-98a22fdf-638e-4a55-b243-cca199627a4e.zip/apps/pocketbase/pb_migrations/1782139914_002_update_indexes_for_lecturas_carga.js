/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("lecturas_carga");
  collection.indexes.push("CREATE INDEX idx_lecturas_carga_tanque_id ON lecturas_carga (tanque_id)");
  collection.indexes.push("CREATE INDEX idx_lecturas_carga_tipo_lectura ON lecturas_carga (tipo_lectura)");
  collection.indexes.push("CREATE INDEX idx_lecturas_carga_created ON lecturas_carga (created)");
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("lecturas_carga");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_lecturas_carga_tanque_id"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_lecturas_carga_tipo_lectura"));
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_lecturas_carga_created"));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})