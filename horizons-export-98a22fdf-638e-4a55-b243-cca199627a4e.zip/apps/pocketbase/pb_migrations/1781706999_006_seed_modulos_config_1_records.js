/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("modulos_config");

  const record0 = new Record(collection);
    record0.set("nombre", "drv");
    record0.set("ubicacion", "Secci\u00f3n Dashboard");
    record0.set("estado", true);
    record0.set("orden", 8);
    record0.set("icono", "gauge");
    record0.set("roles_permitidos", ["Superadmin", "Administrador", "Despachador"]);
    record0.set("colecciones", ["drv", "drv_registros", "drv_evidencias"]);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})