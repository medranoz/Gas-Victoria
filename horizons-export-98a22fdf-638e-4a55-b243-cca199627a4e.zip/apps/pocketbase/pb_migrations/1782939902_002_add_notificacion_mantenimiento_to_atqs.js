/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("atqs");

  const existing = collection.fields.getByName("notificacion_mantenimiento");
  if (existing) {
    if (existing.type === "bool") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("notificacion_mantenimiento"); // exists with wrong type, remove first
  }

  collection.fields.add(new BoolField({
    name: "notificacion_mantenimiento",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("atqs");
    collection.fields.removeByName("notificacion_mantenimiento");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})