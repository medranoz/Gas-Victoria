/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("proveedores");

  const existing = collection.fields.getByName("estado");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("estado"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "estado",
    required: true,
    values: ["Activo", "Inactivo"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("proveedores");
    collection.fields.removeByName("estado");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})