/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("modulos_config");
  const field = collection.fields.getByName("ubicacion");
  field.values = ["Header Principal", "Secci\u00f3n Dashboard", "/atqs", "/carga"];
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("modulos_config");
  const field = collection.fields.getByName("ubicacion");
  if (!field) { console.log("Field not found, skipping revert"); return; }
  field.values = ["Header Principal", "Secci\u00f3n Dashboard", "/atqs"];
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection or field not found, skipping revert");
      return;
    }
    throw e;
  }
})