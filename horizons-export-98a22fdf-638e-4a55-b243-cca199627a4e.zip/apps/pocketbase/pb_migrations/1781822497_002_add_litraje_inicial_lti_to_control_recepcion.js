/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("control_recepcion");

  const existing = collection.fields.getByName("litraje_inicial_lti");
  if (existing) {
    if (existing.type === "number") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("litraje_inicial_lti"); // exists with wrong type, remove first
  }

  collection.fields.add(new NumberField({
    name: "litraje_inicial_lti",
    required: true,
    min: 0
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("control_recepcion");
    collection.fields.removeByName("litraje_inicial_lti");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})